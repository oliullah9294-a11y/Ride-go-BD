let role='passenger';
function show(name){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  const el=document.getElementById('screen-'+name);
  if(el) el.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
}
function setRole(r){role=r}
document.getElementById('resetBtn').onclick=()=>{role='passenger';show('welcome')};
